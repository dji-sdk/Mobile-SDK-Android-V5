#!/usr/bin/env bash
# Standalone bootstrap: bash 3.2+ (macOS), no Node/npm needed to start.
set -euo pipefail

PACKAGE='@open-pilot/wizard@latest'
PACKAGE_EXPLICIT=0 DELIVERY_VERSION=''
TOOLS='' INSTALL_TOOLS=0 YES=0 JSON=0 DRY_RUN=0 SKIP_NODE=0
REGISTRY='' PREFIX='' NODE_VERSION='' NODE_MIRROR='https://nodejs.org/dist'
STAGE='arguments' INSTALLED=false TEMP_DIR=''

usage() {
  cat <<'HELP'
Usage: bash install.sh [options]
  Delivery default: manifest-selected local package; no manifest: npm latest.
  --yes                 Confirm installation without prompts (Agent/CI)
  --json                stdout: one JSON result; progress: stderr (requires --yes)
  --dry-run             Print plan only; no downloads or file changes
  --package <spec>      @open-pilot/wizard[@version|@tag], HTTPS .tgz, or local .tgz
  --tools <list>        claude,opencode,codex; default: auto-detect
  --install-tools       Install explicitly selected AI hosts (requires --tools)
  --skip-node           Fail instead of downloading missing/old Node or npm
  --prefix <directory>  npm install prefix; default: writable current prefix or user directory
  --registry <url>      npm registry for this run only
  --node-version <x.y.z> Use a specific Node version when a download is needed
  --node-mirror <url>   Node distribution mirror (HTTPS, default: nodejs.org/dist)
  --help
Only global OPW assets are synchronized. Never runs setup in the current directory.
Re-run the same command to upgrade. Local .tgz still needs uncached npm dependencies.
HELP
}

fail() { printf '[%s] %s\n' "$STAGE" "$*" >&2; exit 1; }
log() { printf '%s\n' "$*" >&2; }
cleanup() { if [ -n "$TEMP_DIR" ] && [ -d "$TEMP_DIR" ]; then /bin/rm -rf -- "$TEMP_DIR"; fi; }
on_exit() {
  local code=$?
  trap - EXIT
  cleanup
  if [ "$code" -ne 0 ] && [ "$JSON" -eq 1 ]; then
    printf '{"schemaVersion":1,"ok":false,"stage":"%s","installed":%s,"error":"See stderr for details","nextSteps":["Resolve the failed stage and re-run the installer"]}\n' "$STAGE" "$INSTALLED"
  fi
  exit "$code"
}
trap on_exit EXIT

while [ "$#" -gt 0 ]; do
  case "$1" in
    --yes) YES=1; shift ;;
    --json) JSON=1; shift ;;
    --dry-run) DRY_RUN=1; shift ;;
    --skip-node) SKIP_NODE=1; shift ;;
    --install-tools) INSTALL_TOOLS=1; shift ;;
    --help|-h) usage; exit 0 ;;
    --package|--tools|--prefix|--registry|--node-version|--node-mirror)
      [ "$#" -ge 2 ] && [ -n "$2" ] || fail "Missing value for $1"
      case "$1" in
        --package) PACKAGE=$2; PACKAGE_EXPLICIT=1 ;; --tools) TOOLS=$2 ;; --prefix) PREFIX=$2 ;;
        --registry) REGISTRY=$2 ;; --node-version) NODE_VERSION=$2 ;; --node-mirror) NODE_MIRROR=$2 ;;
      esac
      shift 2 ;;
    *) fail "Unknown option: $1 (see --help)" ;;
  esac
done
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
HELPER="$SCRIPT_DIR/install-package.mjs"
[ -f "$HELPER" ] || HELPER="$SCRIPT_DIR/src/core/install-package.mjs"
[ -f "$HELPER" ] || fail 'Missing install-package.mjs; download the complete delivery ZIP'
if [ "$PACKAGE_EXPLICIT" -eq 0 ] && [ -f "$SCRIPT_DIR/manifest.json" ]; then
  STAGE='delivery'
  package_file=$(sed -n 's/^  "packageFile": "\([^"]*\)",*$/\1/p' "$SCRIPT_DIR/manifest.json")
  package_hash=$(sed -n 's/^  "packageSha256": "\([^"]*\)",*$/\1/p' "$SCRIPT_DIR/manifest.json")
  DELIVERY_VERSION=$(sed -n 's/^  "version": "\([^"]*\)",*$/\1/p' "$SCRIPT_DIR/manifest.json")
  [[ "$package_file" =~ ^open-pilot-wizard-[a-zA-Z0-9.+_-]+\.tgz$ ]] || fail 'Invalid delivery manifest packageFile'
  [[ "$package_hash" =~ ^[a-f0-9]{64}$ ]] || fail 'Invalid delivery manifest checksum'
  [[ "$DELIVERY_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+([+-][a-zA-Z0-9.-]+)?$ ]] || fail 'Invalid delivery version'
  PACKAGE="$SCRIPT_DIR/$package_file"
  [ -f "$PACKAGE" ] && [ ! -L "$PACKAGE" ] || fail 'Delivery package missing; refusing to fall back to npm latest'
  actual=$(shasum -a 256 "$PACKAGE"); actual=${actual%% *}
  [ "$actual" = "$package_hash" ] || fail 'Delivery package SHA-256 mismatch'
  STAGE='arguments'
fi
[ "$JSON" -eq 0 ] || [ "$YES" -eq 1 ] || [ "$DRY_RUN" -eq 1 ] || fail '--json requires --yes'
if [ -n "$TOOLS" ]; then
  [[ "$TOOLS" =~ ^(claude|opencode|codex)(,(claude|opencode|codex))*$ ]] || fail 'Invalid --tools'
fi
[ "$INSTALL_TOOLS" -eq 0 ] || [ -n "$TOOLS" ] || fail '--install-tools requires --tools'
[ -z "$NODE_VERSION" ] || [[ "$NODE_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || fail 'Invalid --node-version'
[[ "$NODE_MIRROR" == https://* ]] || fail '--node-mirror must use HTTPS'
NODE_MIRROR=${NODE_MIRROR%/}
if [[ "$PACKAGE" == @open-pilot/wizard || "$PACKAGE" == @open-pilot/wizard@* ]]; then
  [[ "$PACKAGE" =~ ^@open-pilot/wizard(@[a-zA-Z0-9.+_-]+)?$ ]] || fail 'Invalid package version/tag'
elif [[ "$PACKAGE" == https://* ]]; then
  : # npm validates the downloaded package below; URL may include a signed query.
elif [ -f "$PACKAGE" ] && [[ "$PACKAGE" == *.tgz ]]; then
  PACKAGE="$(cd "$(dirname "$PACKAGE")" && pwd)/$(basename "$PACKAGE")"
else
  fail '--package must be @open-pilot/wizard, an HTTPS tarball, or an existing local .tgz'
fi
if [ -n "$PREFIX" ]; then
  [[ "$PREFIX" == /* ]] || PREFIX="$PWD/$PREFIX"
fi
SYSTEM=$(uname -s) ARCH=$(uname -m)
[ "$SYSTEM" = Darwin ] || fail 'install.sh supports macOS; use install.ps1 on Windows'
case "$ARCH" in arm64|aarch64) ARCH=arm64 ;; x86_64) ARCH=x64 ;; *) fail "Unsupported CPU: $ARCH" ;; esac
if [ "$DRY_RUN" -eq 1 ]; then
  log 'Plan: check Node >=20.19.0 and npm; download verified user-scoped Node LTS if needed.'
  log "Install/upgrade: $PACKAGE; sync global assets only; inspect optional dependencies."
  if [ "$JSON" -eq 1 ]; then
    printf '{"schemaVersion":1,"ok":true,"stage":"plan","installed":false,"dryRun":true}\n'
  else
    log 'No changes made. Use --yes for unattended execution.'
  fi
  exit 0
fi
if [ "$YES" -eq 0 ]; then
  [ -t 0 ] || fail 'Non-interactive installation requires --yes (or use --dry-run)'
  printf 'Install/upgrade %s, Node if needed, and global OPW assets? [y/N] ' "$PACKAGE" >&2
  read -r answer
  case "$answer" in y|Y|yes|YES) ;; *) fail 'Installation cancelled' ;; esac
fi
[ -n "${HOME:-}" ] && [ "$HOME" != / ] || fail 'A user HOME directory is required'

STAGE='node'
OPW_HOME="$HOME/.open-pilot-wizard"
NODE='' NPM=''
compatible_node() {
  local version major minor patch
  version=$("$1" --version 2>/dev/null) || return 1
  [[ "$version" =~ ^v([0-9]+)\.([0-9]+)\.([0-9]+)$ ]] || return 1
  major=${BASH_REMATCH[1]} minor=${BASH_REMATCH[2]} patch=${BASH_REMATCH[3]}
  [ "$major" -gt 20 ] || { [ "$major" -eq 20 ] && { [ "$minor" -gt 19 ] || { [ "$minor" -eq 19 ] && [ "$patch" -ge 0 ]; }; }; }
}
find_runtime() {
  local candidate=$1 dir npm
  [ -x "$candidate" ] && compatible_node "$candidate" || return 1
  dir=$(dirname "$candidate")
  npm="$dir/npm"
  [ -x "$npm" ] || npm=$(command -v npm || true)
  [ -n "$npm" ] || return 1
  PATH="$dir:$PATH" "$npm" --version >/dev/null 2>&1 || return 1
  NODE=$candidate NPM=$npm
}
SYSTEM_NODE=$(command -v node || true)
if ! find_runtime "$SYSTEM_NODE" && ! find_runtime "$OPW_HOME/runtime/node/bin/node"; then
  [ "$SKIP_NODE" -eq 0 ] || fail 'Node >=20.19.0 and a working npm are required (--skip-node)'
  for tool in curl tar shasum; do command -v "$tool" >/dev/null || fail "Missing download dependency: $tool"; done
  TEMP_DIR=$(mktemp -d "${TMPDIR:-/tmp}/opw-install.XXXXXX")
  download() { curl --fail --location --silent --show-error --retry 3 --connect-timeout 20 --max-time 900 --proto '=https' --proto-redir '=https' "$1" -o "$2"; }
  if [ -z "$NODE_VERSION" ]; then
    # Deliberately select a supported LTS line, not `latest` (which may be Current).
    log "Resolving Node 24 LTS from $NODE_MIRROR ..."
    download "$NODE_MIRROR/latest-v24.x/SHASUMS256.txt" "$TEMP_DIR/SHASUMS256.txt"
    NODE_VERSION=$(sed -n "s/.*node-v\\([0-9][0-9.]*\\)-darwin-${ARCH}\\.tar\\.gz.*/\\1/p" "$TEMP_DIR/SHASUMS256.txt" | head -1)
    [[ "$NODE_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || fail 'Could not resolve Node version'
  else
    download "$NODE_MIRROR/v$NODE_VERSION/SHASUMS256.txt" "$TEMP_DIR/SHASUMS256.txt"
  fi
  archive="node-v${NODE_VERSION}-darwin-${ARCH}.tar.gz"
  hash=$(awk -v file="$archive" '$2 == file { print $1 }' "$TEMP_DIR/SHASUMS256.txt")
  [[ "$hash" =~ ^[a-fA-F0-9]{64}$ ]] || fail "No valid checksum for $archive"
  log "Downloading Node $NODE_VERSION ($ARCH), without replacing system Node ..."
  download "$NODE_MIRROR/v$NODE_VERSION/$archive" "$TEMP_DIR/$archive"
  actual=$(shasum -a 256 "$TEMP_DIR/$archive"); actual=${actual%% *}
  [ "$actual" = "$hash" ] || fail 'Node SHA-256 verification failed'
  tar -xzf "$TEMP_DIR/$archive" -C "$TEMP_DIR"
  candidate="$TEMP_DIR/node-v${NODE_VERSION}-darwin-${ARCH}"
  find_runtime "$candidate/bin/node" || fail 'Downloaded Node/npm is not compatible'
  mkdir -p "$OPW_HOME/runtime"
  # Replace only our own runtime after it has been verified.
  if [ -e "$OPW_HOME/runtime/node" ]; then
    [ ! -e "$OPW_HOME/runtime/node.previous" ] || fail 'Previous runtime exists; inspect runtime/node.previous before retrying'
    mv "$OPW_HOME/runtime/node" "$OPW_HOME/runtime/node.previous"
  fi
  mv "$candidate" "$OPW_HOME/runtime/node"
  find_runtime "$OPW_HOME/runtime/node/bin/node" || fail 'Installed Node runtime failed verification'
fi
NODE_BIN=$(dirname "$NODE")
export PATH="$NODE_BIN:$PATH"
log "Using Node $("$NODE" --version): $NODE"
log "Using npm $("$NPM" --version): $NPM"
if [ -n "$DELIVERY_VERSION" ]; then
  STAGE='delivery'
  "$NODE" "$HELPER" delivery "$SCRIPT_DIR" >/dev/null
fi

STAGE='package'
if [ -z "$PREFIX" ]; then
  current=$("$NPM" config get prefix)
  if [[ "$NODE" == "$OPW_HOME/runtime/node/"* ]]; then
    # Runtime replacement must not also remove the installed CLI.
    PREFIX="$OPW_HOME/npm"
  elif [ -d "$current" ] && [ -w "$current" ] && { [ ! -d "$current/lib" ] || [ -w "$current/lib" ]; }; then
    PREFIX=$current
  else
    PREFIX="$OPW_HOME/npm"
  fi
fi
mkdir -p "$PREFIX"
export NPM_CONFIG_PREFIX="$PREFIX"
[ -z "$REGISTRY" ] || export NPM_CONFIG_REGISTRY="$REGISTRY"
# macOS Bash 3.2 treats an empty array as unset under `set -u`.
run_npm() {
  local command=$1
  shift
  if [ -n "$REGISTRY" ]; then "$NPM" "$command" --registry "$REGISTRY" "$@"
  else "$NPM" "$command" "$@"; fi
}
if [ -z "$TEMP_DIR" ]; then TEMP_DIR=$(mktemp -d "${TMPDIR:-/tmp}/opw-install.XXXXXX"); fi
log "Resolving/validating $PACKAGE (npm prefix: $PREFIX) ..."
# Snapshot before installation; no arbitrary source-directory prepare scripts.
if run_npm pack "$PACKAGE" --ignore-scripts --json --pack-destination "$TEMP_DIR" >"$TEMP_DIR/pack.json"; then
  :
else
  code=$?
  exit "$code"
fi
"$NODE" "$HELPER" pack "$TEMP_DIR/pack.json" "$TEMP_DIR/package-path" "$DELIVERY_VERSION"
SNAPSHOT=$(cat "$TEMP_DIR/package-path")
if run_npm install --global --prefix "$PREFIX" -- "$SNAPSHOT" >&2; then
  :
else
  # Exit outside the redirected function so Bash 3.2's EXIT trap keeps stdout.
  code=$?
  exit "$code"
fi
INSTALLED=true
ROOT=$("$NPM" root --global --prefix "$PREFIX")
ENTRY=$("$NODE" "$HELPER" entry "$ROOT" "$TEMP_DIR/pack.json")

STAGE='path'
export PATH="$PREFIX/bin:$NODE_BIN:$PATH"
mkdir -p "$OPW_HOME"
"$NODE" "$HELPER" record "$HOME" "$PREFIX" "$NODE" darwin
printf '# Generated by OPW installer; user-scoped PATH only.\nexport PATH=%q:%q:"$PATH"\n' "$PREFIX/bin" "$NODE_BIN" >"$OPW_HOME/activate.sh"
source_line='[ ! -f "$HOME/.open-pilot-wizard/activate.sh" ] || . "$HOME/.open-pilot-wizard/activate.sh"'
for profile in "$HOME/.zshrc" "$HOME/.zprofile" "$HOME/.bashrc" "$HOME/.bash_profile"; do
  if [ ! -f "$profile" ] || ! grep -Fq "$source_line" "$profile"; then
    printf '\n# Open Pilot Wizard\n%s\n' "$source_line" >>"$profile"
  fi
done

STAGE='bootstrap'
args=(bootstrap --yes)
[ -z "$TOOLS" ] || args+=(--tools "$TOOLS")
[ "$INSTALL_TOOLS" -eq 0 ] || args+=(--install-tools)
[ "$JSON" -eq 0 ] || args+=(--json)
# Buffer JSON so a failed child produces exactly one document, not two.
if [ "$JSON" -eq 1 ]; then
  if "$NODE" "$ENTRY" "${args[@]}" >"$TEMP_DIR/result.json"; then
    cat "$TEMP_DIR/result.json"
  else
    code=$?
    if [ -s "$TEMP_DIR/result.json" ]; then cat "$TEMP_DIR/result.json"; JSON=0; fi
    exit "$code"
  fi
else
  "$NODE" "$ENTRY" "${args[@]}"
  log "For this terminal: source \"$OPW_HOME/activate.sh\""
fi
