﻿[CmdletBinding()]
param(
  [string]$Package = '@open-pilot/wizard@latest',
  [string]$Tools,
  [switch]$InstallTools,
  [switch]$Yes,
  [switch]$Json,
  [switch]$DryRun,
  [switch]$SkipNode,
  [string]$Prefix,
  [string]$Registry,
  [string]$NodeVersion,
  [string]$NodeMirror = 'https://nodejs.org/dist',
  [switch]$Help
)

# Windows PowerShell 5.1 and PowerShell 7; no Node/npm required to start.
$ErrorActionPreference = 'Stop'
$stage = 'arguments'
$installed = $false
$tempRoot = $null
$resultEmitted = $false
$exitCode = 0
function Write-ProgressLine([string]$Text) { [Console]::Error.WriteLine($Text) }
function Find-CommandPath([string]$Name) {
  $command = Get-Command $Name -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($command) { return $command.Source }
  return $null
}
function Assert-NativeArgument([string]$Value) {
  # npm.cmd is interpreted by cmd.exe; do not silently expand variables/metacharacters.
  if ($Value -match '["%!\r\n&|<>^()]') { throw '参数含 Windows npm.cmd 无法可靠传递的字符。请换用普通路径或下载地址。' }
}
function Invoke-Checked([string]$File, [string[]]$Arguments, [switch]$Capture) {
  # PS 5.1 represents native stderr as ErrorRecord; progress is not a terminating error.
  $oldPreference = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  $stderrFile = [IO.Path]::GetTempFileName()
  try {
    $output = @(& $File @Arguments 2> $stderrFile)
    $code = $LASTEXITCODE
    if (Test-Path -LiteralPath $stderrFile) {
      foreach ($line in @(Get-Content -LiteralPath $stderrFile)) { Write-ProgressLine ([string]$line) }
    }
  } finally {
    $ErrorActionPreference = $oldPreference
    Remove-Item -LiteralPath $stderrFile -ErrorAction SilentlyContinue
  }
  if ($Capture) {
    if ($code -ne 0) {
      foreach ($line in $output) { Write-ProgressLine ([string]$line) }
      throw "命令失败: $File (退出码 $code)"
    }
    return ($output -join "`n")
  }
  foreach ($line in $output) { Write-ProgressLine ([string]$line) }
  if ($code -ne 0) { throw "命令失败: $File (退出码 $code)" }
}
function Test-Runtime([string]$Candidate) {
  if (-not $Candidate -or -not (Test-Path -LiteralPath $Candidate -PathType Leaf)) { return $false }
  try {
    $version = (Invoke-Checked $Candidate @('--version') -Capture).Trim()
    if ($version -notmatch '^v(\d+)\.(\d+)\.(\d+)$') { return $false }
    $major = [int]$Matches[1]; $minor = [int]$Matches[2]
    if ($major -lt 20 -or ($major -eq 20 -and $minor -lt 19)) { return $false }
    $directory = Split-Path -Parent $Candidate
    $candidateNpm = Join-Path $directory 'npm.cmd'
    if (-not (Test-Path -LiteralPath $candidateNpm)) { $candidateNpm = Find-CommandPath 'npm.cmd' }
    if (-not $candidateNpm) { return $false }
    $oldPath = $env:Path
    $env:Path = "$directory;$env:Path"
    try { Invoke-Checked $candidateNpm @('--version') -Capture | Out-Null }
    finally { $env:Path = $oldPath }
    $script:node = $Candidate; $script:npm = $candidateNpm
    return $true
  } catch { return $false }
}
function Download-File([string]$Url, [string]$Destination) {
  if ($Url -notmatch '^https://') { throw '下载必须使用 HTTPS' }
  for ($attempt = 1; $attempt -le 3; $attempt++) {
    try {
      Invoke-WebRequest -Uri $Url -OutFile $Destination -UseBasicParsing -TimeoutSec 900 | Out-Null
      return
    } catch {
      if ($attempt -eq 3) { throw }
      Start-Sleep -Seconds $attempt
    }
  }
}
function Add-UserPath([string]$Entry) {
  Assert-NativeArgument $Entry
  $current = [Environment]::GetEnvironmentVariable('Path', 'User')
  $parts = @($current -split ';' | Where-Object { $_ })
  $parts = @($parts | Where-Object { $_.TrimEnd('\') -ine $Entry.TrimEnd('\') })
  [Environment]::SetEnvironmentVariable('Path', ((@($Entry) + $parts) -join ';'), 'User')
  $env:Path = "$Entry;$env:Path"
}

try {
  if ($Help) {
    @'
Usage: powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 [options]
  Delivery default: manifest-selected local package; no manifest: npm latest.
  -Yes                    Non-interactive confirmation (Agent/CI)
  -Json                   stdout: one JSON result; progress: stderr (requires -Yes)
  -DryRun                 Print plan only; no downloads or file changes
  -Package <spec>          @open-pilot/wizard[@version|@tag], HTTPS .tgz or local .tgz
  -Tools <list>            claude,opencode,codex; default: auto-detect
  -InstallTools           Install explicitly selected hosts (requires -Tools)
  -SkipNode               Fail instead of installing missing/old Node or npm
  -Prefix <directory>     npm prefix; default: writable current prefix or user directory
  -Registry <url>         npm registry for this run only
  -NodeVersion <x.y.z>    Specific Node version when download is needed
  -NodeMirror <url>       HTTPS Node distribution mirror (default: nodejs.org/dist)
Only global OPW assets are synchronized. Never runs setup in the current directory.
Re-run the same command to upgrade. Local .tgz still needs uncached npm dependencies.
'@
    return
  }
  if ($Json -and -not $Yes -and -not $DryRun) { throw '-Json requires -Yes' }
  if ($Tools -and $Tools -notmatch '^(claude|opencode|codex)(,(claude|opencode|codex))*$') { throw 'Invalid -Tools' }
  if ($InstallTools -and -not $Tools) { throw '-InstallTools requires -Tools' }
  if ($NodeVersion -and $NodeVersion -notmatch '^\d+\.\d+\.\d+$') { throw 'Invalid -NodeVersion' }
  if ($NodeMirror -notmatch '^https://') { throw '-NodeMirror must use HTTPS' }
  $NodeMirror = $NodeMirror.TrimEnd('/')
  $helper = Join-Path $PSScriptRoot 'install-package.mjs'
  if (-not (Test-Path -LiteralPath $helper)) { $helper = Join-Path $PSScriptRoot 'src\core\install-package.mjs' }
  if (-not (Test-Path -LiteralPath $helper)) { throw 'Missing install-package.mjs; download the complete delivery ZIP' }
  $deliveryVersion = $null
  $manifestFile = Join-Path $PSScriptRoot 'manifest.json'
  if (-not $PSBoundParameters.ContainsKey('Package') -and (Test-Path -LiteralPath $manifestFile)) {
    $stage = 'delivery'
    $delivery = Get-Content -LiteralPath $manifestFile -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($delivery.schemaVersion -ne 1 -or $delivery.packageName -ne '@open-pilot/wizard' -or
        $delivery.packageFile -notmatch '^open-pilot-wizard-[a-zA-Z0-9.+_-]+\.tgz$' -or
        $delivery.packageSha256 -notmatch '^[a-f0-9]{64}$') { throw 'Invalid delivery manifest' }
    $Package = Join-Path $PSScriptRoot $delivery.packageFile
    if (-not (Test-Path -LiteralPath $Package -PathType Leaf)) { throw 'Delivery package missing; refusing to fall back to npm latest' }
    if ((Get-FileHash -LiteralPath $Package -Algorithm SHA256).Hash -ine $delivery.packageSha256) { throw 'Delivery package SHA-256 mismatch' }
    $deliveryVersion = $delivery.version
    $stage = 'arguments'
  }
  if ($Package -match '^@open-pilot/wizard(@[a-zA-Z0-9.+_-]+)?$' -or $Package -match '^https://') {
    # npm metadata validation below checks the downloaded tarball identity.
  } elseif ($Package.EndsWith('.tgz') -and (Test-Path -LiteralPath $Package -PathType Leaf)) {
    $Package = (Resolve-Path -LiteralPath $Package).Path
  } else { throw '-Package must be @open-pilot/wizard, HTTPS tarball, or existing local .tgz' }
  foreach ($value in @($Package, $Prefix, $Registry)) { Assert-NativeArgument $value }
  if ($env:OS -ne 'Windows_NT') { throw 'Use install.sh on macOS' }
  if (-not [Environment]::Is64BitOperatingSystem -or $env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') {
    throw 'install.ps1 currently supports Windows x64 only'
  }
  if ($DryRun) {
    Write-ProgressLine 'Plan: check Node >=20.19.0 and npm; download verified user-scoped Node 24 LTS if needed.'
    Write-ProgressLine "Install/upgrade: $Package; sync global assets only; inspect optional dependencies."
    if ($Json) { '{"schemaVersion":1,"ok":true,"stage":"plan","installed":false,"dryRun":true}' }
    return
  }
  if (-not $Yes) {
    if ([Console]::IsInputRedirected) { throw 'Non-interactive installation requires -Yes (or use -DryRun)' }
    $answer = Read-Host "Install/upgrade $Package, Node if needed, and global OPW assets? [y/N]"
    if ($answer -notmatch '^(y|yes)$') { throw 'Installation cancelled' }
  }
  # Node emits UTF-8; Windows PowerShell 5.1 otherwise decodes with the OEM codepage.
  [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
  $OutputEncoding = [Console]::OutputEncoding
  $userHome = $env:USERPROFILE
  if (-not $userHome) { $userHome = [Environment]::GetFolderPath('UserProfile') }
  if (-not $userHome) { throw 'A user home directory is required' }
  $opwHome = Join-Path $userHome '.open-pilot-wizard'
  Assert-NativeArgument $opwHome
  $stage = 'node'
  $node = $null; $npm = $null
  $existingNode = Find-CommandPath 'node.exe'
  if (-not (Test-Runtime $existingNode) -and -not (Test-Runtime (Join-Path $opwHome 'runtime\node\node.exe'))) {
    if ($SkipNode) { throw 'Node >=20.19.0 and working npm required (-SkipNode)' }
    $tempRoot = Join-Path ([IO.Path]::GetTempPath()) ('opw-install-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tempRoot | Out-Null
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $checksums = Join-Path $tempRoot 'SHASUMS256.txt'
    if (-not $NodeVersion) {
      Write-ProgressLine "Resolving Node 24 LTS from $NodeMirror ..."
      Download-File "$NodeMirror/latest-v24.x/SHASUMS256.txt" $checksums
      $line = Get-Content -LiteralPath $checksums | Where-Object { $_ -match 'node-v(\d+\.\d+\.\d+)-win-x64\.zip$' } | Select-Object -First 1
      if (-not $line -or $line -notmatch 'node-v(\d+\.\d+\.\d+)-win-x64\.zip$') { throw 'Could not resolve Node version' }
      $NodeVersion = $Matches[1]
    } else { Download-File "$NodeMirror/v$NodeVersion/SHASUMS256.txt" $checksums }
    $archive = "node-v$NodeVersion-win-x64.zip"
    $line = Get-Content -LiteralPath $checksums | Where-Object { $_ -match ("^[a-fA-F0-9]{64}\s+" + [regex]::Escape($archive) + '$') } | Select-Object -First 1
    if (-not $line) { throw "No valid checksum for $archive" }
    $expectedHash = ($line -split '\s+')[0]
    $zip = Join-Path $tempRoot $archive
    Write-ProgressLine "Downloading Node $NodeVersion (x64), without replacing system Node ..."
    Download-File "$NodeMirror/v$NodeVersion/$archive" $zip
    if ((Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash -ine $expectedHash) { throw 'Node SHA-256 verification failed' }
    Expand-Archive -LiteralPath $zip -DestinationPath $tempRoot
    $candidate = Join-Path $tempRoot "node-v$NodeVersion-win-x64"
    if (-not (Test-Runtime (Join-Path $candidate 'node.exe'))) { throw 'Downloaded Node/npm is not compatible' }
    $runtime = Join-Path $opwHome 'runtime'
    New-Item -ItemType Directory -Force -Path $runtime | Out-Null
    $target = Join-Path $runtime 'node'
    if (Test-Path -LiteralPath $target) {
      if (Test-Path -LiteralPath "$target.previous") { throw 'Previous runtime exists; inspect runtime\node.previous before retrying' }
      Move-Item -LiteralPath $target -Destination "$target.previous"
    }
    Move-Item -LiteralPath $candidate -Destination $target
    if (-not (Test-Runtime (Join-Path $target 'node.exe'))) { throw 'Installed Node runtime failed verification' }
  }
  $nodeDirectory = Split-Path -Parent $node
  $env:Path = "$nodeDirectory;$env:Path"
  Write-ProgressLine ("Using Node " + (Invoke-Checked $node @('--version') -Capture) + ": $node")
  Write-ProgressLine ("Using npm " + (Invoke-Checked $npm @('--version') -Capture) + ": $npm")
  if ($deliveryVersion) {
    $stage = 'delivery'
    Invoke-Checked $node @($helper, 'delivery', $PSScriptRoot) -Capture | Out-Null
  }

  $stage = 'package'
  if (-not $Prefix) {
    if ($node.StartsWith((Join-Path $opwHome 'runtime\node') + '\', [StringComparison]::OrdinalIgnoreCase)) {
      $Prefix = Join-Path $opwHome 'npm'
    } else {
      $currentPrefix = (Invoke-Checked $npm @('config', 'get', 'prefix') -Capture).Trim()
      $probe = Join-Path $currentPrefix ('.opw-write-probe-' + [guid]::NewGuid().ToString('N'))
      try {
        [IO.File]::WriteAllText($probe, '')
        Remove-Item -LiteralPath $probe
        $Prefix = $currentPrefix
      } catch { $Prefix = Join-Path $opwHome 'npm' }
    }
  }
  $Prefix = [IO.Path]::GetFullPath($Prefix)
  Assert-NativeArgument $Prefix
  New-Item -ItemType Directory -Force -Path $Prefix | Out-Null
  $env:NPM_CONFIG_PREFIX = $Prefix
  if ($Registry) { $env:NPM_CONFIG_REGISTRY = $Registry }
  $registryArguments = @()
  if ($Registry) { $registryArguments = @('--registry', $Registry) }
  if (-not $tempRoot) {
    $tempRoot = Join-Path ([IO.Path]::GetTempPath()) ('opw-install-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tempRoot | Out-Null
  }
  Write-ProgressLine "Resolving/validating $Package (npm prefix: $Prefix) ..."
  $packArguments = @('pack', $Package, '--ignore-scripts', '--json', '--pack-destination', $tempRoot) + $registryArguments
  $packOutput = Invoke-Checked $npm $packArguments -Capture
  $packJson = Join-Path $tempRoot 'pack.json'
  [IO.File]::WriteAllText($packJson, $packOutput, [Text.UTF8Encoding]::new($false))
  $packagePath = Join-Path $tempRoot 'package-path'
  $validationArgs = @($helper, 'pack', $packJson, $packagePath)
  if ($deliveryVersion) { $validationArgs += $deliveryVersion }
  Invoke-Checked $node $validationArgs
  $snapshot = Get-Content -LiteralPath $packagePath -Raw -Encoding UTF8
  Assert-NativeArgument $snapshot
  $installArguments = @('install', '--global', '--prefix', $Prefix) + $registryArguments + @('--', $snapshot)
  Invoke-Checked $npm $installArguments
  $installed = $true
  $globalRoot = (Invoke-Checked $npm @('root', '--global', '--prefix', $Prefix) -Capture).Trim()
  $entry = (Invoke-Checked $node @($helper, 'entry', $globalRoot, $packJson) -Capture).Trim()
  $stage = 'path'
  $originalUserPath = [Environment]::GetEnvironmentVariable('Path', 'User')
  $addedPath = @(@($nodeDirectory, $Prefix) | Where-Object {
    $entry = $_
    -not (@($originalUserPath -split ';') | Where-Object { $_.TrimEnd('\') -ieq $entry.TrimEnd('\') })
  })
  $addedPathJson = ConvertTo-Json -InputObject @($addedPath) -Compress
  # Record exact additions before changing persistent PATH; preserve ownership across upgrades.
  $pathRecord = Join-Path $tempRoot 'path-added.json'
  [IO.File]::WriteAllText($pathRecord, $addedPathJson, [Text.UTF8Encoding]::new($false))
  # Pass JSON via a file to avoid PowerShell 5.1 native argument quote handling.
  # Use the shared helper with a JSON file rather than inline executable text.
  Invoke-Checked $node @($helper, 'record-file', $userHome, $Prefix, $node, 'win32', $pathRecord)
  Add-UserPath $nodeDirectory
  Add-UserPath $Prefix
  New-Item -ItemType Directory -Force -Path $opwHome | Out-Null
  $activation = '$env:Path = ''' + ($Prefix + ';' + $nodeDirectory + ';').Replace("'", "''") + ''' + $env:Path'
  $activation | Set-Content -LiteralPath (Join-Path $opwHome 'activate.ps1') -Encoding UTF8

  $stage = 'bootstrap'
  $arguments = @('bootstrap', '--yes')
  if ($Tools) { $arguments += @('--tools', $Tools) }
  if ($InstallTools) { $arguments += '--install-tools' }
  if ($Json) { $arguments += '--json' }
  # Keep native stdout separate from stderr for the single-JSON contract.
  $resultFile = Join-Path $tempRoot 'result.json'
  $errorFile = Join-Path $tempRoot 'bootstrap-stderr.txt'
  $oldPreference = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  try {
    & $node $entry @arguments 1> $resultFile 2> $errorFile
    $code = $LASTEXITCODE
  } finally { $ErrorActionPreference = $oldPreference }
  foreach ($line in @(Get-Content -LiteralPath $errorFile)) { Write-ProgressLine ([string]$line) }
  $text = Get-Content -LiteralPath $resultFile -Raw
  if ($Json -and $text) {
    $text | ConvertFrom-Json | Out-Null
    [Console]::Out.WriteLine($text.Trim())
    $resultEmitted = $true
  } elseif ($text) { [Console]::Out.WriteLine($text.Trim()) }
  if ($code -ne 0) { throw "OPW 包已安装，但 bootstrap 未完成（退出码 $code）；请处理错误后重跑" }
  if (-not $Json) { Write-ProgressLine '请重新打开终端和 AI 宿主；或在当前 PowerShell 中加载 ~/.open-pilot-wizard/activate.ps1。' }
}
catch {
  $exitCode = 1
  Write-ProgressLine ("[$stage] " + $_.Exception.Message)
  if ($Json -and -not $resultEmitted) {
    [ordered]@{
      schemaVersion = 1; ok = $false; stage = $stage; installed = $installed
      error = $_.Exception.Message
      nextSteps = @('Resolve the failed stage and re-run the installer')
    } | ConvertTo-Json -Depth 6 -Compress
  }
}
finally {
  if ($tempRoot -and (Test-Path -LiteralPath $tempRoot)) {
    Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
  }
}
if ($exitCode -ne 0) { exit $exitCode }
