# Open Pilot Wizard 安装与使用

用户只需下载可信交付 ZIP，解压后执行一个安装入口；不需要克隆源码或提前配置 Node。
维护者构建、版本提交、tag 和发布见仓库中的 `RELEASE.md`；不要在用户工程里运行构建发布命令。

## 1. 下载、解压、安装

交付目录包含：

```text
open-pilot-wizard-installer-<版本>/
├── INSTALL.md
├── INSTALL_AGENT.md
├── install.sh
├── install.ps1
├── install-package.mjs
├── open-pilot-wizard-<版本>.tgz
└── manifest.json
```

只解压外层 ZIP，**不必解压 `.tgz`**。保持这些文件在同一个目录。
在交付目录打开终端并执行：

**macOS Apple Silicon / Intel**：

```bash
bash ./install.sh
```

**Windows 10 22H2 / 11 x64，PowerShell 5.1 / 7**：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

确认后，脚本自动：

1. 读取交付 manifest，验证本地包；默认安装**交付版本**，不是 npm latest。
2. 检查 Node ≥20.19 和可用 npm；缺失或过旧时从可信发行源下载 SHA-256 校验后的
   Node 24 LTS 到用户目录，不卸载系统 Node，不要求 Homebrew、winget 或管理员权限。
3. 安装/升级 OPW，从实际安装位置启动新 CLI。
4. 识别 AI 宿主，同步 Skills、知识库、共享脚本、模板及宿主入口。
5. 检查 OpenSpec 能否启动，输出依赖状态和下一步。

只修改本机全局资产、用户级 PATH 和托管状态，**不在当前目录执行 setup 或修改业务工程**。
用户修改过的托管文件保留并报告冲突，失败退出非零，不自动强制覆盖。
没有 AI 宿主时不默认安装 Claude 或全部宿主；构建环境、宿主登录和真机不是安装成功的前提。

## 2. 交给 AI Agent 安装

把交付 ZIP 或解压目录的本地路径告诉有文件/终端能力的 Agent，并输入：

> 按照交付包中的 INSTALL_AGENT.md 帮我安装 Open Pilot Wizard；需要权限时请请求批准。

Agent 得到安装授权后执行：

```bash
bash ./install.sh --yes --json
```

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Yes -Json
```

stdout 只有一份 JSON，进度在 stderr。检查退出码及 `ok`、`stage`、`installed`、
`conflicts`、`warnings`、`nextSteps`；包已安装不等于同步完成。
仅聊天附件上传不能安装到用户电脑；系统权限审批不能绕过。
登录、密钥与许可证接受由用户完成。完整执行约定见 `INSTALL_AGENT.md`。

## 3. 安装后开始使用

1. 重启终端和 AI 宿主，让 PATH、Skills、桥接生效。当前终端也可加载：
   - macOS：`source "$HOME/.open-pilot-wizard/activate.sh"`
   - PowerShell：`. "$env:USERPROFILE\.open-pilot-wizard\activate.ps1"`
2. 没有宿主时任选一个，确认后执行 `opw env install codex --yes`（可换 claude/opencode），
   完成登录，再执行 `opw update --global` 安装对应 Skills。
3. 已有 Android 工程：进入**目标工程根目录**，执行：
   ```bash
   opw setup
   opw doctor
   ```
   非空且不是 Android/OpenSpec 工程的目录会被拒绝，避免污染。
4. 新建工程：进入准备创建工程的空目录，在宿主中描述创建 Pilot 插件的需求。
5. 构建依赖缺失：`opw env setup --tools codex` 只展示计划；逐项确认后执行
   `opw env install <component> --yes`。Android Studio 可选，实际构建仍需 JDK/Android SDK。
   **JDK ≥17 即满足最低版本要求，不强制使用 17**；`jdk17` 保留为历史组件名。
   已有 JDK 21、25 等合格版本时跳过安装，不自动降级。最低版本通过不保证与项目
   Gradle、AGP 或其他工具完全兼容，需实际构建验证；确实缺失时默认安装 JDK 17。

默认自动识别宿主，也可指定 `opw setup --tools claude,opencode,codex`。
Claude Code 切换 `/output-style pilot-plugin-dev`；OpenCode 用 Tab 切换 `pilot-plugin-dev`；
Codex 直接描述需求或调用 `opw` / `opw-plugin-dev` Skill。

## 4. 后续升级：安装与项目同步分开

收到新版 ZIP 后，解压到新目录，重复第 1 节的安装命令。可以重装同版本恢复同步。
安装器只更新全局资产；进入每个已有项目根目录执行：

```bash
opw update
opw doctor
```

命令职责：

| 入口 | 职责 |
|---|---|
| 交付包 `install.sh` / `install.ps1` | 安装或升级 CLI，补齐必要运行依赖，全局同步、自检与指引 |
| `opw setup` | 目标工程首次初始化，并检查全局资产 |
| `opw update` | 同步当前 CLI 的项目配置及全局资产，不下载新版 CLI |
| `opw update --global` | 仅全局同步，不初始化当前项目，不下载新版 CLI |
| `opw doctor` | 项目自检；修复流程须另外确认 |
| `opw env setup/install` | 按需管理可选开发环境 |

失败恢复：包已安装、全局同步未完成时，可重跑安装脚本或
`opw bootstrap --yes --json`；不要自动 `--force`。
历史 `opw update --package <新包.tgz>` 和 `opw self update --yes` 保留兼容，
前者仍要求严格升级并按工程模式同步，后者复用安装器；不作为另一套推荐安装教程。

## 5. 项目版本控制与换机器

OPW 写入插件工程的内容分为“本机生成物”和“项目协作文档”两类：

| 路径 | 是否提交 Git | 说明 |
| --- | --- | --- |
| `.open-pilot-wizard/` | 不提交 | 本机 manifest、日志、统计和运行状态；历史配置备份不能重建，清理前自行保管 |
| `openspec/schemas/` | 不提交 | OPW 生成的 schema；其中会渲染当前用户的全局资产绝对路径，具有机器差异 |
| `openspec/config.yaml` | 可以提交 | 用户维护的项目默认 schema、上下文与规则；OPW 不再追加 DJI 配置片段 |
| `openspec/specs/`、`openspec/changes/` | 建议提交 | 团队的需求规格、设计方案、任务与验证记录 |

已有 OpenSpec 工程可以直接使用 OPW：专属 schemas 独立安装在 `openspec/schemas/`，
每个 OPW 任务自动绑定对应 schema，原有默认 schema、规格、任务和原生命令保持不变。
用户在 AI 宿主中的入口与批准/验证流程不变，不需要选择 schema。

旧安装的 OPW 配置片段在 setup/update/uninstall 时统一安全处理：只有标记完整、manifest
checksum 匹配且移除后 YAML 有效，才备份到
`.open-pilot-wizard/backups/openspec-config/` 并移除片段，块外原文保持不变。
修改过、缺少 checksum 或标记异常时保留并报告，请先备份，再按 `opw doctor` 的原因手动处理。
`--force` 只用于托管资产，不会强制删除共享配置片段；冲突未处理不宣称安装/升级全部完成。
备份可能包含项目上下文中的秘密，不提交、不分享；卸载 OPW 托管资产不会删除这些备份。

新生成的插件工程模板已经通过 `.gitignore` 忽略：

```gitignore
/.open-pilot-wizard/
/openspec/schemas/
```

如果把 `openspec/schemas/` 提交进了 Git，另一台机器克隆后首次执行 `opw update` 时，本机没有
`.open-pilot-wizard/manifest.json`，同时 schema 里的全局资产绝对路径又来自旧机器；checksum
机制无法区分“另一台机器生成的旧文件”和“用户手工修改”，因此会报“schema 已被修改或不受管理”。

存量仓库按下面步骤清理一次：

```bash
# 确认 .gitignore 已包含上面两条忽略规则
git rm -r --cached --ignore-unmatch .open-pilot-wizard openspec/schemas
git commit -m "chore: stop tracking OPW generated files"
```

之后新克隆的机器正常执行：

```bash
opw update
```

如果某台机器在清理前已经遇到冲突，可以先执行一次：

```bash
opw update --force
```

该命令会重建本机 manifest 并覆盖 OPW 托管的 schema 等资产；不会强制覆盖共享配置、`openspec/specs/`、
`openspec/changes/` 或业务源码。若确实手工定制过 schema 文件，请先备份或迁移定制内容。

> **Windows 路径说明**：Skill/脚本中引用的路径在安装时已渲染为本机绝对路径，不依赖 shell 的 `~` 展开，PowerShell / cmd / Git Bash 下行为一致。用户 home 目录变更（如迁移账户）后，重跑一次 `opw setup` 刷新路径。


## 6. 参数与进阶安装

优先用完整 ZIP。安装脚本和 `install-package.mjs` 是配套文件，不能只下载一个脚本。
无 manifest 时安装入口默认 npm latest；有 manifest 但缺包/校验失败时不回退到 latest。
显式 `--package` / `-Package` 可以覆盖来源，按需使用可信本地 `.tgz`、HTTPS tarball 或 npm 版本：

```bash
bash ./install.sh --yes --package "/path/to/new-package.tgz"
bash ./install.sh --yes --package "@open-pilot/wizard@latest"
```

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Yes -Package "C:\Downloads\new-package.tgz"
```

| macOS 参数 | Windows 参数 | 用途 |
|---|---|---|
| `--yes` | `-Yes` | 已授权的非交互执行 |
| `--json` | `-Json` | 机器结果；安装时须配合 yes |
| `--dry-run` | `-DryRun` | 只预览，不下载安装或写文件 |
| `--tools codex` | `-Tools codex` | 选择 Skills 注入宿主，不安装宿主 |
| `--install-tools` | `-InstallTools` | 显式安装所选宿主，必须指定 tools 并确认 |
| `--prefix <目录>` | `-Prefix <目录>` | 指定 npm 用户级安装位置 |
| `--registry <URL>` | `-Registry <URL>` | 本次 npm 源，不修改 npmrc |
| `--skip-node` | `-SkipNode` | Node/npm 不满足时失败，不下载 |
| `--node-version x.y.z` | `-NodeVersion x.y.z` | 需要下载 Node 时指定版本 |
| `--node-mirror <URL>` | `-NodeMirror <URL>` | 可信 HTTPS Node 发行镜像 |

没有手工维护 Node 的必要；已有兼容 Node 可直接复用。用户级安装默认复用可写 prefix，
否则使用 `~/.open-pilot-wizard/npm`；脚本下载的 Node 放在 `runtime/node`，与 CLI 分开。
系统包管理器、代理和认证问题依环境处理，脚本不关闭 TLS 校验。
Windows npm.cmd 对无法可靠传递的 `%`、`!`、`&` 等参数明确报错，支持普通空格/中文路径。

仅当已有 Node/npm 且明确不使用交付安装器时，手动安装兼容入口为：

```bash
npm install -g @open-pilot/wizard
opw bootstrap --yes
```

它不代替交付 manifest 校验。源码开发的 `npm ci` / `npm link` 属于维护者流程，见 RELEASE.md。

## 7. 包内容、联网与数据边界

程序包包括：OPW CLI、6 个 Skills、宿主适配入口/桥接、知识库、OpenSpec schemas/config、
共享检查脚本、插件工程模板（含 UXSDK 快照、模板 SDK 三件套和 Gradle wrapper）、安装说明。
**不内置 Node、所有 npm 运行依赖、AI 宿主程序、JDK/Android SDK/Android Studio。**
因此本地 `.tgz` 仍可能下载未缓存的 OpenSpec 等 npm 依赖；当前是联网安装包，不是完整离线包。
SHA-256 校验提供完整性检查，不代替可信发布渠道或独立签名。

OPW 记录本地白名单统计和必要诊断状态，不上传对话或源码；已有宿主配置按托管规则保护。
安装成功只表示包、全局同步和必要运行依赖通过，不表示工程、飞行器或真机已经验证。

## 8. 排障与卸载

- 找不到 `opw`/`node`：重启终端/Agent，或加载第 3 节 activation 文件；检查 Node 版本切换。
- 校验失败/缺包：重新取得可信完整 ZIP，不删除 manifest 来绕过检查。
- 同步冲突：查看 JSON conflicts 和 stderr，保留用户修改；人工比对后再决定是否覆盖。
- 项目故障：`opw doctor --json`；确认后 `opw doctor --fix` 创建修复 change，由 repair Skill 处理。
- 反馈已有问题：项目根目录执行 `opw report`，默认汇总已有脱敏证据，不自动采集真机或截图。
- 仅卸载目标项目的托管配置：在项目根目录执行 `opw uninstall`，保留用户修改与规格/变更记录。
- 卸载本机 OPW：见下面的完整卸载步骤。

### 完整卸载本机 OPW

**先备份 `~/.open-pilot-wizard/` 内需要保留的内容**。以下命令确认删除整个私有目录，
其中的用户修改和用户自行放入的文件也会删除：

```bash
opw self uninstall --yes
# Agent 读取结构化结果：
opw self uninstall --yes --json
```

不带 `--yes` 只展示删除计划，不执行。操作范围：

| 内容 | 行为 |
|---|---|
| 当前安装位置的 OPW CLI | 通过 npm 卸载，不误用另一 Node prefix |
| `~/.open-pilot-wizard/` | 整体删除：Node/runtime.previous、包/模板/知识库/脚本、缓存、环境快照、偏好、统计、manifest、activation 和用户放入的文件 |
| 宿主目录中的 OPW Skills、入口和桥接 | manifest/checksum 匹配才删除；用户修改、未知文件保留并报告 |
| macOS shell 启动文件 | 只移除安装器生成的 OPW 激活行及相邻标记，保留其他配置 |
| Windows 用户 PATH | 清理指向 OPW 私有目录的条目；原有/仍共用的 Node/npm 路径保留，已记录新增且不再有执行文件的 npm 路径可移除 |
| 业务工程、规格/变更、外部 AI 宿主、系统 Node、JDK/Android SDK/Studio | 不删除 |
| 下载的交付 ZIP/tgz、其他 Node prefix 中的 OPW | 不扫描或删除 |

私有目录没有 manifest 或 manifest 损坏时仍可明确确认整体删除，但不能据此猜测并删除宿主文件。
根 HOME、链接到其他位置的私有目录以及越界宿主路径会被拒绝或跳过，避免误删。

Windows 无法立即删除当前正在运行的自带 Node，使用临时外部卸载进程等待 CLI 退出后清理。
此时首次 JSON 是 `pending: true`、`ok: false`、`directoryRemoved: false`，退出码只表示调度成功。
**最终成功以 `resultFile` 中的 `ok: true`、`stage: complete`、`directoryRemoved: true` 为准**；
结果在系统临时目录，安装目录删除后仍可读取。Agent 必须等待最终结果，不能把 pending 当作成功。
失败会保留外部卸载记录；关闭占用进程并处理权限错误后，可按记录继续或经确认人工清理。
安装包可用于恢复 CLI 后再次卸载，但不要在有卸载进程未结束时同时重装。

卸载不会跨项目修改业务目录；若要移除各项目的 OPW 配置，**先在各项目根目录执行
`opw uninstall`，最后再卸载本机 CLI**。项目卸载会直接移除 OPW 配置标记块，定制该块时先备份。
完成后重启终端和 AI 宿主。当前进程的环境变量无法从子进程自动刷新。
宿主中保留的自定义桥接配置可能引用已删除的共享脚本，应按卸载报告人工调整。

设备验证偏好、日志和开发工作流的完整说明见 README 对应章节，安装文档不重复维护。
