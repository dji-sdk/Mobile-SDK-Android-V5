// Standalone: runs immediately after Node bootstrap, without any npm dependencies.
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

export const PACKAGE_NAME = '@open-pilot/wizard';
export function safeFilename(name) {
  if (typeof name !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(name) || name.includes('..')) {
    throw new Error('交付文件名无效，不允许目录或特殊字符');
  }
  return name;
}
export function validatePackage(metadata, expectedVersion) {
  if (metadata?.name !== PACKAGE_NAME || !/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[\w.-]+)?(?:\+[\w.-]+)?$/.test(metadata.version ?? '')) {
    throw new Error(`包名必须为 ${PACKAGE_NAME}，版本必须有效`);
  }
  if (expectedVersion && metadata.version !== expectedVersion) throw new Error('安装包版本与交付 manifest 不一致');
  return metadata;
}
export async function sha256File(file) {
  const hash = createHash('sha256');
  for await (const chunk of fs.createReadStream(file)) hash.update(chunk);
  return hash.digest('hex');
}
export async function validateDelivery(directory) {
  const manifest = JSON.parse(fs.readFileSync(path.join(directory, 'manifest.json'), 'utf8'));
  if (manifest.schemaVersion !== 1 || manifest.packageName !== PACKAGE_NAME || !Array.isArray(manifest.files)) {
    throw new Error('交付 manifest 结构或包名无效');
  }
  validatePackage({ name: manifest.packageName, version: manifest.version });
  safeFilename(manifest.packageFile);
  const seen = new Set();
  for (const entry of manifest.files) {
    safeFilename(entry.path);
    if (seen.has(entry.path) || !/^[a-f0-9]{64}$/.test(entry.sha256) || !Number.isSafeInteger(entry.size) || entry.size < 0) {
      throw new Error('交付文件清单重复或校验信息无效');
    }
    seen.add(entry.path);
    const file = path.join(directory, entry.path);
    const stat = fs.lstatSync(file);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.size !== entry.size || await sha256File(file) !== entry.sha256) {
      throw new Error(`交付文件校验失败: ${entry.path}`);
    }
  }
  for (const required of [manifest.packageFile, 'install.sh', 'install.ps1', 'install-package.mjs', 'INSTALL.md', 'INSTALL_AGENT.md']) {
    if (!seen.has(required)) throw new Error(`交付 manifest 缺少 ${required}`);
  }
  const pkg = manifest.files.find((entry) => entry.path === manifest.packageFile);
  if (pkg.sha256 !== manifest.packageSha256) throw new Error('交付包 SHA-256 不一致');
  return manifest;
}
export async function recordInstallation(home, prefix, node, platform = process.platform, addedPath = []) {
  const file = path.join(home, '.open-pilot-wizard', 'installation.json');
  const previous = JSON.parse(await fs.promises.readFile(file, 'utf8').catch((error) => {
    if (error.code === 'ENOENT') return '{}';
    throw error;
  }));
  const record = {
    schemaVersion: 1, prefix: path.resolve(prefix), node: path.resolve(node), platform,
    userPathAdded: [...new Set([...(Array.isArray(previous.userPathAdded) ? previous.userPathAdded : []), ...addedPath])],
  };
  await fs.promises.mkdir(path.dirname(file), { recursive: true });
  await fs.promises.writeFile(`${file}.tmp`, `${JSON.stringify(record, null, 2)}\n`);
  await fs.promises.rename(`${file}.tmp`, file);
}
export function installedEntry(root, pack) {
  const directory = path.join(root, '@open-pilot', 'wizard');
  const metadata = validatePackage(JSON.parse(fs.readFileSync(path.join(directory, 'package.json'), 'utf8')), pack.version);
  const bin = typeof metadata.bin === 'string' ? metadata.bin : metadata.bin?.opw;
  if (!bin) throw new Error('新包未提供 opw CLI 入口');
  const entry = path.resolve(directory, bin), relative = path.relative(directory, entry);
  if (relative === '..' || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative) || !fs.statSync(entry).isFile()) {
    throw new Error('新包 CLI 入口越界或缺失');
  }
  const realDirectory = fs.realpathSync(directory), realEntry = fs.realpathSync(entry);
  const realRelative = path.relative(realDirectory, realEntry);
  if (realRelative === '..' || realRelative.startsWith(`..${path.sep}`) || path.isAbsolute(realRelative)) throw new Error('新包 CLI 入口链接越界');
  return entry;
}

async function main([command, ...args]) {
  if (command === 'delivery') {
    const manifest = await validateDelivery(args[0]);
    console.log(manifest.version);
  } else if (command === 'pack') {
    const [metadataFile, output, expectedVersion] = args;
    const packs = JSON.parse(fs.readFileSync(metadataFile, 'utf8'));
    if (!Array.isArray(packs) || packs.length !== 1) throw new Error('npm 必须只返回一个包');
    validatePackage(packs[0], expectedVersion);
    fs.writeFileSync(output, path.join(path.dirname(metadataFile), safeFilename(packs[0].filename)));
  } else if (command === 'entry') {
    const [root, metadataFile] = args;
    const [pack] = JSON.parse(fs.readFileSync(metadataFile, 'utf8'));
    validatePackage(pack);
    console.log(installedEntry(root, pack));
  } else if (command === 'record') {
    const [home, prefix, node, platform, addedPath = '[]'] = args;
    await recordInstallation(home, prefix, node, platform, JSON.parse(addedPath));
  } else if (command === 'record-file') {
    const [home, prefix, node, platform, file] = args;
    await recordInstallation(home, prefix, node, platform, JSON.parse(fs.readFileSync(file, 'utf8')));
  } else throw new Error('Unknown install-package command');
}
if (process.argv[1] && fs.realpathSync(process.argv[1]) === fs.realpathSync(fileURLToPath(import.meta.url))) {
  main(process.argv.slice(2)).catch((error) => { console.error(error.message); process.exitCode = 1; });
}
