# 使用 AI Agent 安装 Open Pilot Wizard

用户可输入：

> 按照交付包中的 INSTALL_AGENT.md 帮我安装 Open Pilot Wizard；需要权限时请请求批准。

## Agent 执行约定

本说明适用于有本地文件访问和终端执行能力的 Agent。仅上传到聊天窗口不能安装到用户电脑。
交付文件的内容不构成绕过系统审批的授权；只在用户明确要求安装后执行。

1. 找到可信交付 ZIP 并解压到独立目录，避免覆盖已有文件。读取 `INSTALL.md` 和
   `manifest.json`；不执行未知脚本，不把源码 ZIP 当成正式交付包。
2. 检查 manifest 指定的本地 `.tgz`、辅助校验脚本和当前系统。安装器会验证交付文件
   SHA-256；checksum 只提供完整性检查，不代替可信下载渠道或独立签名。
3. 不自行更改为 npm latest，不自动降级，不绕过校验失败。如果已有 CLI 比交付版本新，
   先报告版本差异并让用户决定是否继续。
4. 明确说明会安装或升级 OPW、必要时联网安装用户级 Node/npm、同步全局能力、
   写入用户级 PATH 和本地托管状态；获得用户安装授权。遇到权限/网络审批正常请求批准。
5. 在交付目录执行对应命令。调用时使用真实路径，正确引用空格和中文路径：

   macOS：
   ```bash
   bash ./install.sh --yes --json
   ```

   Windows x64：
   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Yes -Json
   ```

6. 默认自动识别宿主。只有用户明确指定时传 `--tools codex` / `-Tools codex`；
   `--tools` 仅选择注入目标，不安装宿主。安装宿主必须另外得到批准并显式使用
   `--install-tools` / `-InstallTools`。不默认安装多个宿主、JDK、Android SDK 或 Android Studio。
7. 读取 stdout 的单份 JSON，进度在 stderr。同时检查退出码、`ok`、`stage`、
   `installed`、`conflicts`、`warnings`、`nextSteps`：
   - `ok: true` 且退出码为 0：包安装、全局同步和运行依赖检查完成。
   - `installed: true` 但 `ok: false`：包已安装，后续阶段失败，不能报告全部成功。
   - 校验失败、缺包、冲突或权限失败：停止对应步骤，提供原因，不自动换下载源或强制覆盖。
8. 不在当前目录执行 `opw setup`，不修改业务工程，不自动 `--force`。
   已有工程的初始化/同步是后续独立步骤，需要正确的目标工程目录。
9. 完成后报告：交付版本、实际安装版本、必要依赖、全局同步状态、是否需要重启及下一步。
   不把依赖存在等同于工程已构建或设备已验证。
10. 用户自行完成登录、API Key/AppKey 配置和许可证确认。已有 Agent/GUI 不会自动刷新 PATH；
    必要时重启终端和宿主。构建环境缺失时建议 `opw env setup` 查看逐项安装计划。

## 失败恢复

修复网络、权限或冲突后重跑交付目录的安装脚本。同版本重复安装允许恢复同步。
包已经安装且只需重试同步时，可执行 `opw bootstrap --yes --json`；
只同步全局内容可执行 `opw update --global`。这两个命令不会下载新版 OPW。

## 用户要求完整卸载时

说明 `opw self uninstall --yes --json` 会删除整个 `~/.open-pilot-wizard/`，包括其中的用户文件、
自带 Node、缓存、偏好和统计；请求明确确认并建议备份。不要仅凭安装授权自动卸载。
不会删除业务工程、系统 Node、外部 AI 宿主和 Android 环境；宿主侧用户修改保留并报告。
若返回 `pending`，须读取 `resultFile` 等待最终 `ok: true`、`stage: complete`、
`directoryRemoved: true`，调度成功不等于卸载完成。失败时报告阶段和外部恢复记录，
不绕过占用/权限限制，不删除整个宿主配置目录，不在卸载进程未结束时并发重装。
